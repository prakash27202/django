from django.urls import path
from app import views

from .views import productdetails,productlist,home

urlpatterns=[
    path('register1',views.register1),
    path('register',views.register),
    path('login',views.login),
    path('home',views.home),
    path('products',productlist.as_view(),name='productlist'),
    path('cartadd',views.cartadd,name="cartpath"),
    path('products/<slug>/',productdetails.as_view(),name="products"),
]

app_name="core"