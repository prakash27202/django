from django.db import models
from django.shortcuts import reverse
from django.contrib.auth.models import User
from multiselectfield import MultiSelectField
# Create your models here.



class Cutomers(models.Model):
    fname = models.CharField(max_length=200)
    lname = models.CharField(max_length=200)
    mno = models.IntegerField()
    email = models.CharField(max_length=200)
    password = models.CharField(max_length=200)
    cpassword = models.CharField(max_length=200)

    def __str__(self):
        return self.fname

class category(models.Model):
    category=models.CharField(max_length=200)

    def __str__(self):
        return self.category

class subcategory(models.Model):
    subcategory=models.CharField(max_length=200)

    def __str__(self):
        return self.subcategory

sizez=(
    ('S','S'),
    ('M','M'),
    ('L','L'),
    ('XL','XL')
)
class products(models.Model):

    pname = models.CharField(max_length=200)
    category = models.ForeignKey(category, null=True, db_column='category', blank=True, on_delete=models.CASCADE)
    subcategory = models.ForeignKey(subcategory, null=True, db_column='subcategory', blank=True, on_delete=models.CASCADE)
    oldprice = models.IntegerField()
    orgprice = models.IntegerField()
    size =MultiSelectField(choices=sizez)
    desc = models.TextField()
    qty = models.IntegerField()
    img1 = models.ImageField()
    img2 = models.ImageField()
    img3 = models.ImageField()
    slug = models.SlugField()

    def __str__(self):
        return self.pname

    def get_absolute_url(self):
        return reverse("core:products", kwargs={
                'slug': self.slug
        })

    def get_all_products(self):
        return products.objects.all()

    def get_productsBy_id(category_id):

        if category_id:
            return products.objects.filter(category=category_id)
        else:
            return products.objects.all()


class orderItem(models.Model):
    item=models.ForeignKey(products,on_delete=models.CASCADE)

    def __str__(self):
        return self.pname

class cart(models.Model):

    user=models.ForeignKey(User,on_delete=models.CASCADE)
    product=models.ForeignKey(products,on_delete=models.CASCADE)
    status=models.BooleanField(default=False)

    def __str__(self):
        return self.user.username