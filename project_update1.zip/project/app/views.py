from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import auth,User
from django.views.generic import ListView,DetailView
from .models import products,Cutomers,category,subcategory,cart
from django.contrib import messages
# Create your views here.



def register(request):
    if request.method == "POST":

        fist_name = request.POST.get('fname')
        last_name = request.POST.get('lname')
        username=request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password')
        password2 = request.POST.get('cpassword')

        user = User.objects.create_user(first_name=fist_name, last_name=last_name,email=email, password=password1,username=username)
        user.save()
        return redirect('/admin')
    else:
        return render(request, 'login.html')

def register1(request):
    if request.method == "POST":

        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        user1 = User.objects.create_user(first_name=first_name,last_name=last_name,username=username, email=email, password = password1)
        user1.save()
        return redirect('/admin')
    else:
        return render(request, 'userregister.html')


def login(request):
    if request.method=="POST":

        username=request.POST['email']
        password=request.POST['password']
        user=auth.authenticate(username=username,password=password)

        if user is not None:
            auth.login(request,user)
            return redirect('/products')
        else:
            return HttpResponse("invalid credentials")
    else:
            return render(request,"login.html")


def productlist(request):
    context={}

    context["dataset"] = products.objects.all()
    context["dataset"] = category.objects.all()
    return render(request , 'product-list.html',context)

def home(request):
    pass
    return render(request ,'index.html')

def cartadd(request):
    context = {}
    items=cart.objects.filter(user_id=request.user.id,status=False)
    context["items"]=items
    if request.user.is_authenticated:
        if request.method=="POST":
            pid=request.POST['pid']

            product=get_object_or_404(products,id=pid)
            usr=get_object_or_404(User,id=request.user.id)
            c=cart(user=usr,product=product)
            c.save()
    else:
        context["status"]="Please login into your account"
    return render(request,"cart.html",context)

class productlist(ListView):

    model = products
    template_name = "product-list.html"

class productdetails(DetailView):
    model = products
    template_name = "product-detail.html"

