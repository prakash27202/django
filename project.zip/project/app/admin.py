from django.contrib import admin
from .models import products,subcategory,category,orderItem,Cutomers
# Register your models here.
admin.site.register(products)
admin.site.register(category)
admin.site.register(subcategory)
admin.site.register(orderItem)
admin.site.register(Cutomers)

#admin.site.register(order)
